int pidfile_create(const char *pidFile, pid_t pid);
