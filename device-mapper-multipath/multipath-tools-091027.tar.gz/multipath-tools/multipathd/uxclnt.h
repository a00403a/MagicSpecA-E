int uxclnt(char * inbuf);
