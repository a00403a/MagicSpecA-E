#ifndef _HP_SW_H
#define _HP_SW_H

int hp_sw (struct checker *);
int hp_sw_init (struct checker *);
void hp_sw_free (struct checker *);

#endif /* _HP_SW_H */
