#ifndef _DICT_H
#define _DICT_H

#ifndef _VECTOR_H
#include "vector.h"
#endif

void init_keywords(void);

#endif /* _DICT_H */
