void path_group_prio_update (struct pathgroup * pgp);
int select_path_group (struct multipath * mpp);
