#include <stdio.h>

#include <prio.h>

int getprio (struct path * pp)
{
	return 1;
}
