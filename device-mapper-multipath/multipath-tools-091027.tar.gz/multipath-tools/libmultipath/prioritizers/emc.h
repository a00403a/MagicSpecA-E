#ifndef _EMC_H
#define _EMC_H

#define PRIO_EMC "emc"
int prio_emc(struct path * pp);

#endif
