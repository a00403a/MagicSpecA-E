#ifndef _RDAC_H
#define _RDAC_H

#define PRIO_RDAC "rdac"
int prio_rdac(struct path * pp);

#endif
