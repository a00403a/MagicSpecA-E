#ifndef _NETAPP_H
#define _NETAPP_H

#define PRIO_NETAPP "netapp"
int prio_netapp(struct path * pp);

#endif
