#ifndef _HP_SW_H
#define _HP_SW_H

#define PRIO_HP_SW "hp_sw"
int prio_hp_sw(struct path * pp);

#endif
