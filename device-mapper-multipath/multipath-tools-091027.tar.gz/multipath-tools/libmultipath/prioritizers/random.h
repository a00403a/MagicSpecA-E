#ifndef _RANDOM_H
#define _RANDOM_H

#define PRIO_RANDOM "random"
int prio_random(struct path * pp);

#endif
