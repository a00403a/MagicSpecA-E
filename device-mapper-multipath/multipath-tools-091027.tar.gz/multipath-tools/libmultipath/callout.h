#ifndef _CALLOUT_H
#define _CALLOUT_H

int execute_program(char *, char *, int);
int apply_format (char *, char *, struct path *);

#endif /* _CALLOUT_H */
