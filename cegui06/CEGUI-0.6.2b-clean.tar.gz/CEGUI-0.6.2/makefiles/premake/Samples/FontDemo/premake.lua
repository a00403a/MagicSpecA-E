--
-- CEGUI sample premake script
--
sample("FontDemo")
package.files =
{
    matchfiles(pkgdir.."src/*.cpp"),
}
