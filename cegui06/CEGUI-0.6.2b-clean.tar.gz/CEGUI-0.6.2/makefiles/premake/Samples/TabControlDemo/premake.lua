--
-- CEGUI sample premake script
--
sample("TabControlDemo")
package.files =
{
    matchfiles(pkgdir.."src/*.cpp"),
}