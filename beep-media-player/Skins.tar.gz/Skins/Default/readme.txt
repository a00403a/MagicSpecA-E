***********************************
Winamp3 Classified skin for Winamp
(Released July 4, 2004.)
***********************************

This port of the Winamp3 Default skin was created by combining the skins
of PeterPan and John Slegers, with refinements by Wildrose-Wally.

Copyright � 2003, 2004 PeterPan, John Slegers
& Wildrose-Wally. All rights reserved.

********************************************************
Original Readme File From Winamp 3 For 2 by John Slegers
********************************************************

----------------------------------------------------------------------------------
               Winamp 3
               06-02-2003
----------------------------------------------------------------------------------

This skin is made by John Slegers
Nicknames: IlluSionS667
	Lord Hades
E-mail: John.Slegers@pandora.be
Homepage: www.IlluSionS667.tk

----------------------------------------------------------------------------------
               DON'T DREAM YOUR LIFE,
                     LIVE YOUR DREAM
----------------------------------------------------------------------------------

                               ////////////
                               |                  |
                              |    ^        ^    |
                             |     .         .     |
                        (   |           ^          |   )
                             |    \_____/    |
                              \                   /
                                \_          _ /
                                        v 
----------------------------------------------------------------------------------
               "Happiness is not having what you want,
                It's wanting what you have" 
                (Victor Borge)
----------------------------------------------------------------------------------

******************************************************************
Original Readme File From Winamp3 Default Skin For 29x by PeterPan
******************************************************************

Steve Gedikian's Winamp3 skin ported to Winamp2.9x by PeterPan


Version History
-----------------------

1.2  Added this credits file

1.1  Bug fix in the position bar

1.0  Initial release
       Skin created by doing lots of screen captures 
       of the default Winamp3 skin